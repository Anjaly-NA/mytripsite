import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from "../src/components/Home/Home";
import Popup from "../src/components/Popup/Popup";

function App() {
  return (
    <div>
        <Home/>
    </div>
  );
}

export default App;
